# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 12:32:34 2024

@author: admin
"""


import streamlit as st
def app():
    st.number_imput('enter')