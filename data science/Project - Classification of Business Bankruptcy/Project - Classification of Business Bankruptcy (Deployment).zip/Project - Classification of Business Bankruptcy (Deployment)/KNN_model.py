# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 15:38:56 2024

@author: admin
"""

import pickle
import streamlit as st

def app():
    load = open('knn_model.pkl', 'rb')
    model = pickle.load(load)

    # defining predict function
    def predict(industrial_risk, management_risk, financial_flexibility, credibility, competitiveness, operating_risk):
        prediction = model.predict([[industrial_risk, management_risk, financial_flexibility, credibility, competitiveness, operating_risk]])
        return prediction

    def main():
        st.title('Bankruptcy Prediction')
        # Accept values from user through browser
        industrial_risk = st.number_input('Industrial Risk:')
        management_risk = st.number_input('Management Risk:')
        financial_flexibility = st.number_input('Financial Flexibility:')
        credibility = st.number_input('Credibility:')
        competitiveness = st.number_input('Competitiveness:')
        operating_risk = st.number_input('Operating Risk:')
        
        if st.button('Predict'):
            result = predict(industrial_risk, management_risk, financial_flexibility, credibility, competitiveness, operating_risk)
            if result[0] == 1:
                st.success('Non-Bankruptcy')
            else:
                st.error('Bankruptcy')    
                
    if __name__ == '__main__':
        main()

app()